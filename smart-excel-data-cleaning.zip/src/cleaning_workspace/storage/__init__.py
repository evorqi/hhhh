"""Local job storage."""
